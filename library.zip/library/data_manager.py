import pandas as pd
import os
import shutil
from datetime import datetime

# Paths
DATA_DIR = "data"
SOURCE_FILE = "source/master.xlsx"
BOOKS_FILE = os.path.join(DATA_DIR, "books.xlsx")
USERS_FILE = os.path.join(DATA_DIR, "users.xlsx")
TRANSACTIONS_FILE = os.path.join(DATA_DIR, "transactions.xlsx")
PENDING_FILE = os.path.join(DATA_DIR, "pending_approvals.xlsx")

def load_data():
    """Loads all databases into pandas DataFrames."""
    books = pd.read_excel(BOOKS_FILE)
    users = pd.read_excel(USERS_FILE)
    transactions = pd.read_excel(TRANSACTIONS_FILE)
    try:
        pending = pd.read_excel(PENDING_FILE)
    except FileNotFoundError:
        pending = pd.DataFrame(columns=[
            'transaction_id', 'book_id', 'book_title', 'user_id', 
            'user_name', 'user_email', 'user_mobile', 
            'borrow_date', 'return_date', 'status'
        ])
    
    # Ensure Thanglish columns exist (Schema Migration)
    schema_changed = False
    if 'title_thanglish' not in books.columns:
        books['title_thanglish'] = ""
        schema_changed = True
    if 'author_thanglish' not in books.columns:
        books['author_thanglish'] = ""
        schema_changed = True
        
    # Enforce String Type
    books['title_thanglish'] = books['title_thanglish'].fillna("").astype(str)
    books['author_thanglish'] = books['author_thanglish'].fillna("").astype(str)
        
    if schema_changed:
        save_books(books)
        
    return books, users, transactions, pending

def save_books(df):
    df.to_excel(BOOKS_FILE, index=False)

def save_transactions(df):
    df.to_excel(TRANSACTIONS_FILE, index=False)

def save_users(df):
    df.to_excel(USERS_FILE, index=False)

def save_pending(df):
    df.to_excel(PENDING_FILE, index=False)
    
# ... (Leaving ID/Mobile helpers unchanged) ...

def add_book(title, author, donated_by, title_thanglish, author_thanglish):
    books = pd.read_excel(BOOKS_FILE)
    # Ensure columns exist
    if 'title_thanglish' not in books.columns: books['title_thanglish'] = ""
    if 'author_thanglish' not in books.columns: books['author_thanglish'] = ""

    import re
    ids = books['id'].astype(str).tolist()
    max_num = 0
    for i in ids:
        match = re.search(r'GDL-(\d+)', i)
        if match:
            num = int(match.group(1))
            if num > max_num: max_num = num
            
    new_id = f"GDL-{str(max_num + 1).zfill(3)}"
    new_book = {
        'id': new_id,
        'title': title,
        'author': author,
        'donated_by': donated_by,
        'title_thanglish': title_thanglish,
        'author_thanglish': author_thanglish,
        'status': 'AVAILABLE'
    }
    books = pd.concat([books, pd.DataFrame([new_book])], ignore_index=True)
    save_books(books)
    return True, new_id

def add_book_copies(original_book_id, num_copies):
    """Creates multiple copies of an existing book with new IDs."""
    try:
        num_copies = int(num_copies)
        if num_copies < 1: return False, "Copies must be at least 1"
    except:
        return False, "Invalid number"

    books = pd.read_excel(BOOKS_FILE)
    
    # Get original details
    src_row = books[books['id'] == original_book_id]
    if src_row.empty:
        return False, "Original Book ID not found."
        
    title = src_row.iloc[0]['title']
    author = src_row.iloc[0]['author']
    donated = src_row.iloc[0]['donated_by']
    
    t_thang = src_row.iloc[0].get('title_thanglish', "")
    a_thang = src_row.iloc[0].get('author_thanglish', "")
    
    # ID Gen Logic (Optimized for loop)
    import re
    ids = books['id'].dropna().astype(str).tolist()
    max_num = 0
    for i in ids:
        match = re.search(r'GDL-(\d+)', i)
        if match:
            num = int(match.group(1))
            if num > max_num: max_num = num
            
    new_entries = []
    current_num = max_num + 1
    
    generated_ids = []
    for _ in range(num_copies):
        new_id = f"GDL-{str(current_num).zfill(3)}"
        new_entries.append({
            'id': new_id,
            'title': title,
            'author': author,
            'donated_by': donated,
            'title_thanglish': t_thang,
            'author_thanglish': a_thang,
            'status': 'AVAILABLE'
        })
        generated_ids.append(new_id)
        current_num += 1
        
    books = pd.concat([books, pd.DataFrame(new_entries)], ignore_index=True)
    save_books(books)
    
    return True, f"Added {num_copies} copies! IDs: {generated_ids[0]} to {generated_ids[-1]}"

def update_book_details(book_id, title, author, donated_by, title_thanglish, author_thanglish):
    """Updates existing book details."""
    books = pd.read_excel(BOOKS_FILE)
    # Ensure columns
    if 'title_thanglish' not in books.columns: books['title_thanglish'] = ""
    if 'author_thanglish' not in books.columns: books['author_thanglish'] = ""
    
    idx = books[books['id'] == book_id].index
    if not idx.empty:
        books.at[idx[0], 'title'] = title
        books.at[idx[0], 'author'] = author
        books.at[idx[0], 'donated_by'] = donated_by
        books.at[idx[0], 'title_thanglish'] = title_thanglish
        books.at[idx[0], 'author_thanglish'] = author_thanglish
        save_books(books)
        return True, "Book details updated successfully."
    return False, "Book ID not found."

def get_next_tx_id():
    return f"TX-{datetime.now().strftime('%Y%m%d%H%M%S')}"

def normalize_mobile(val):
    """Clean mobile number robustly."""
    try:
        f_val = float(val)
        i_val = int(f_val)
        return str(i_val)
    except (ValueError, TypeError):
        s = str(val).strip()
        if s.endswith('.0'):
            return s[:-2]
        return s

def borrow_book_request(book_id, user_name, mobile, email):
    """
    Creates a Borrow Request in PENDING_FILE. 
    Book Status -> PENDING
    Transaction Status -> BORROW_REQUESTED
    """
    books = pd.read_excel(BOOKS_FILE)
    try:
        pending = pd.read_excel(PENDING_FILE)
    except FileNotFoundError:
        pending = pd.DataFrame()
    
    # Check availability
    book_idx = books[books['id'] == book_id].index
    if not book_idx.empty:
        current_status = books.at[book_idx[0], 'status']
        if current_status == 'AVAILABLE':
            # Update Book to PENDING
            books.at[book_idx[0], 'status'] = 'PENDING'
            save_books(books)
            
            # Create Pending Record
            new_tx = {
                'transaction_id': get_next_tx_id(),
                'book_id': book_id,
                'book_title': books.at[book_idx[0], 'title'],
                'user_id': 'WALK-IN', 
                'user_name': user_name,
                'user_email': email,
                'user_mobile': mobile,
                'borrow_date': datetime.now().strftime("%Y-%m-%d"),
                'return_date': None,
                'status': 'BORROW_REQUESTED'
            }
            
            if pending.empty:
                pending = pd.DataFrame([new_tx])
            else:
                for col in new_tx.keys():
                    if col not in pending.columns:
                        pending[col] = ""
                pending = pd.concat([pending, pd.DataFrame([new_tx])], ignore_index=True)
                
            save_pending(pending)
            return True, "Borrow request sent! Please wait for Admin approval."
        else:
            return False, f"Book is currently {current_status}."
    return False, "Book not found."

def approve_borrow(transaction_id):
    """
    Admin approves borrow request. 
    Moves record from PENDING_FILE to TRANSACTIONS_FILE.
    Status -> ACTIVE. Book -> BORROWED.
    """
    try:
        pending = pd.read_excel(PENDING_FILE)
    except FileNotFoundError:
        return False, "No pending requests found."
        
    transactions = pd.read_excel(TRANSACTIONS_FILE)
    books = pd.read_excel(BOOKS_FILE)
    
    # Find in Pending
    tx_idx = pending[pending['transaction_id'] == transaction_id].index
    if not tx_idx.empty:
        # Get record
        record = pending.iloc[tx_idx[0]].to_dict()
        
        # Update Status
        record['status'] = 'ACTIVE'
        
        # Add to Transactions
        if transactions.empty:
            transactions = pd.DataFrame([record])
        else:
            for col in record.keys():
                if col not in transactions.columns:
                    transactions[col] = ""
            transactions = pd.concat([transactions, pd.DataFrame([record])], ignore_index=True)
        save_transactions(transactions)
        
        # Remove from Pending
        pending = pending.drop(tx_idx)
        save_pending(pending)
        
        # Update Book Status
        book_id = record['book_id']
        book_idx = books[books['id'] == book_id].index
        if not book_idx.empty:
            books.at[book_idx[0], 'status'] = 'BORROWED'
            save_books(books)
            
        return True, "Borrow request approved. Moved to Active Transactions."
    return False, "Transaction not found in Pending Requests."

def reject_borrow(transaction_id):
    """
    Admin rejects borrow request. 
    Removes from PENDING_FILE.
    Book -> AVAILABLE.
    """
    try:
        pending = pd.read_excel(PENDING_FILE)
    except FileNotFoundError:
        return False, "No pending requests found."
        
    books = pd.read_excel(BOOKS_FILE)
    
    tx_idx = pending[pending['transaction_id'] == transaction_id].index
    if not tx_idx.empty:
        book_id = pending.at[tx_idx[0], 'book_id']
        
        # Remove from Pending
        pending = pending.drop(tx_idx)
        save_pending(pending)
        
        # Release Book
        book_idx = books[books['id'] == book_id].index
        if not book_idx.empty:
            books.at[book_idx[0], 'status'] = 'AVAILABLE'
            save_books(books)
            
        return True, "Borrow request rejected."
    return False, "Transaction not found."

def approve_return(transaction_id):
    """Admin approves return request. Status -> RETURNED. Book -> AVAILABLE."""
    transactions = pd.read_excel(TRANSACTIONS_FILE)
    books = pd.read_excel(BOOKS_FILE)
    
    tx_idx = transactions[transactions['transaction_id'] == transaction_id].index
    if not tx_idx.empty:
        transactions.at[tx_idx[0], 'status'] = 'RETURNED'
        transactions.at[tx_idx[0], 'return_date'] = datetime.now().strftime("%Y-%m-%d")
        save_transactions(transactions)
        
        # Release Book
        book_id = transactions.at[tx_idx[0], 'book_id']
        book_idx = books[books['id'] == book_id].index
        if not book_idx.empty:
            books.at[book_idx[0], 'status'] = 'AVAILABLE'
            save_books(books)
            
        return True, "Return approved. Book is now available."
    return False, "Transaction not found."

def get_user_history(mobile):
    """Returns list of active/pending loans for a mobile number from BOTH files."""
    if not mobile:
        return []
    
    _, _, transactions, pending = load_data()
    
    input_mobile = normalize_mobile(mobile)
    
    results = []
    
    # 1. Check Active/Return Requested in Transactions
    if not transactions.empty:
        transactions['user_mobile'] = transactions['user_mobile'].apply(normalize_mobile)
        user_tx = transactions[
            (transactions['user_mobile'] == input_mobile) & 
            (transactions['status'].isin(['ACTIVE', 'RETURN_REQUESTED']))
        ]
        results.extend(user_tx.to_dict('records'))
        
    # 2. Check Borrow Requested in Pending
    if not pending.empty:
        pending['user_mobile'] = pending['user_mobile'].apply(normalize_mobile)
        user_pending = pending[
            (pending['user_mobile'] == input_mobile) &
            (pending['status'] == 'BORROW_REQUESTED')
        ]
        results.extend(user_pending.to_dict('records'))
        
    return results

def request_return(book_id, mobile):
    """User initiates return."""
    transactions = pd.read_excel(TRANSACTIONS_FILE)
    
    transactions['user_mobile'] = transactions['user_mobile'].apply(normalize_mobile)
    input_mobile = normalize_mobile(mobile)
    
    # Find active transaction
    tx_idx = transactions[
        (transactions['book_id'] == book_id) & 
        (transactions['user_mobile'] == input_mobile) &
        (transactions['status'] == 'ACTIVE')
    ].index
    
    if not tx_idx.empty:
        transactions.at[tx_idx[0], 'status'] = 'RETURN_REQUESTED'
        save_transactions(transactions)
        return True, "Return requested. Waiting for Admin approval."
    
    return False, "Active transaction not found for this book and mobile."

def update_legacy_mobile(transaction_id, new_mobile):
    transactions = pd.read_excel(TRANSACTIONS_FILE)
    tx_idx = transactions[transactions['transaction_id'] == transaction_id].index
    if not tx_idx.empty:
        transactions.at[tx_idx[0], 'user_mobile'] = str(new_mobile)
        save_transactions(transactions)
        return True, "Mobile number updated successfully."
    return False, "Transaction ID not found."

def register_member(name, mobile, email):
    """Registers a new member with a MEM-XXX ID."""
    users = pd.read_excel(USERS_FILE)
    
    # Check if mobile/email already exists? Optional but good practice.
    # casting to string for safe comparison
    if not users.empty:
        if str(mobile) in users['mobile'].astype(str).values:
            return False, "Member with this mobile number already exists."
            
    # Generate ID
    import re
    ids = users['user_id'].dropna().astype(str).tolist()
    max_num = 0
    for i in ids:
        match = re.search(r'MEM-(\d+)', i)
        if match:
            num = int(match.group(1))
            if num > max_num: max_num = num
    
    new_id = f"MEM-{str(max_num + 1).zfill(3)}"
    
    new_user = {
        'user_id': new_id,
        'name': name,
        'email': email,
        'mobile': mobile,
        'role': 'USER'
    }
    
    users = pd.concat([users, pd.DataFrame([new_user])], ignore_index=True)
    save_users(users)
    return True, f"Member Registered Successfully! ID: {new_id}"

def sync_to_master():
    try:
        shutil.copy2(BOOKS_FILE, SOURCE_FILE)
        return True, f"Base Excel updated at {datetime.now()}"
    except Exception as e:
        return False, str(e)

def add_book(title, author, donated_by):
    books = pd.read_excel(BOOKS_FILE)
    import re
    ids = books['id'].astype(str).tolist()
    max_num = 0
    for i in ids:
        match = re.search(r'GDL-(\d+)', i)
        if match:
            num = int(match.group(1))
            if num > max_num: max_num = num
            
    new_id = f"GDL-{str(max_num + 1).zfill(3)}"
    new_book = {
        'id': new_id,
        'title': title,
        'author': author,
        'donated_by': donated_by,
        'status': 'AVAILABLE'
    }
    books = pd.concat([books, pd.DataFrame([new_book])], ignore_index=True)
    save_books(books)
    return True, new_id

def add_book_copies(original_book_id, num_copies):
    """Creates multiple copies of an existing book with new IDs."""
    try:
        num_copies = int(num_copies)
        if num_copies < 1: return False, "Copies must be at least 1"
    except:
        return False, "Invalid number"

    books = pd.read_excel(BOOKS_FILE)
    
    # Get original details
    src_row = books[books['id'] == original_book_id]
    if src_row.empty:
        return False, "Original Book ID not found."
        
    title = src_row.iloc[0]['title']
    author = src_row.iloc[0]['author']
    donated = src_row.iloc[0]['donated_by']
    
    # ID Gen Logic (Optimized for loop)
    import re
    ids = books['id'].dropna().astype(str).tolist()
    max_num = 0
    for i in ids:
        match = re.search(r'GDL-(\d+)', i)
        if match:
            num = int(match.group(1))
            if num > max_num: max_num = num
            
    new_entries = []
    current_num = max_num + 1
    
    generated_ids = []
    for _ in range(num_copies):
        new_id = f"GDL-{str(current_num).zfill(3)}"
        new_entries.append({
            'id': new_id,
            'title': title,
            'author': author,
            'donated_by': donated,
            'status': 'AVAILABLE'
        })
        generated_ids.append(new_id)
        current_num += 1
        
    books = pd.concat([books, pd.DataFrame(new_entries)], ignore_index=True)
    save_books(books)
    
    return True, f"Added {num_copies} copies! IDs: {generated_ids[0]} to {generated_ids[-1]}"

def update_book_details(book_id, title, author, donated_by):
    """Updates existing book details."""
    books = pd.read_excel(BOOKS_FILE)
    
    idx = books[books['id'] == book_id].index
    if not idx.empty:
        books.at[idx[0], 'title'] = title
        books.at[idx[0], 'author'] = author
        books.at[idx[0], 'donated_by'] = donated_by
        save_books(books)
        return True, "Book details updated successfully."
    return False, "Book ID not found."

def update_user_details(user_id, name, mobile, email):
    """Updates existing user details."""
    users = pd.read_excel(USERS_FILE)
    
    idx = users[users['user_id'] == user_id].index
    if not idx.empty:
        users.at[idx[0], 'name'] = name
        users.at[idx[0], 'mobile'] = mobile
        users.at[idx[0], 'email'] = email
        save_users(users)
        return True, "User details updated successfully."
    return False, "User ID not found."
