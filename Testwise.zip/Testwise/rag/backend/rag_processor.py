import os
import tempfile
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.llms import Ollama
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from PyPDF2 import PdfReader
import docx

memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
vectorstore = None

def extract_text(file_path: str) -> str:
    ext = os.path.splitext(file_path)[-1].lower()
    if ext == ".pdf":
        reader = PdfReader(file_path)
        return "\n".join(page.extract_text() or "" for page in reader.pages)
    elif ext == ".docx":
        doc = docx.Document(file_path)
        return "\n".join(p.text for p in doc.paragraphs)
    elif ext == ".txt":
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    else:
        raise ValueError(f"Unsupported file format: {ext}")

def process_document(filename: str, file_content: bytes) -> str:
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(filename)[-1]) as tmp_file:
        tmp_file.write(file_content)
        tmp_file_path = tmp_file.name

    raw_text = extract_text(tmp_file_path)
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    docs = text_splitter.create_documents([raw_text])

    embeddings = OllamaEmbeddings(model="nomic-embed-text")  # pull if not available: `ollama pull nomic-embed-text`
    global vectorstore
    vectorstore = FAISS.from_documents(docs, embeddings)

    os.remove(tmp_file_path)
    return f"{filename} processed and added to vectorstore."

def get_qa_chain():
    if vectorstore is None:
        raise ValueError("No documents uploaded yet.")
    retriever = vectorstore.as_retriever()
    llm = Ollama(model="llama3")  # pull if not available: `ollama pull llama3`
    chain = ConversationalRetrievalChain.from_llm(llm=llm, retriever=retriever, memory=memory, verbose=True)
    return chain
