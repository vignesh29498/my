from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from backend.rag_processor import process_document, get_qa_chain
from backend.schema import AskRequest

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust this in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "RAG Backend is running."}

@app.post("/upload/")
async def upload_files(files: list[UploadFile] = File(...)):
    for file in files:
        content = await file.read()
        result = process_document(file.filename, content)
    return {"status": "ok", "message": result}

@app.post("/ask/")
async def ask_question(req: AskRequest):
    chain = get_qa_chain()
    user_input = f"{req.heading}:\n{req.addtext}"
    result = chain.run(user_input)
    return {"response": result}
