import streamlit as st
import requests

BACKEND_URL = "http://localhost:8000"

st.set_page_config(page_title="RAG App", layout="centered")
st.title("📄 RAG Assistant")

# Sidebar upload
st.sidebar.header("📁 Upload Documents")
uploaded_files = st.sidebar.file_uploader("Choose files", type=["pdf", "docx", "txt"], accept_multiple_files=True)

if st.sidebar.button("Upload"):
    if uploaded_files:
        files = [("files", (file.name, file.read(), file.type)) for file in uploaded_files]
        res = requests.post(f"{BACKEND_URL}/upload/", files=files)
        if res.status_code == 200:
            st.sidebar.success("✅ Files uploaded successfully!")
        else:
            st.sidebar.error(f"❌ Upload failed: {res.text}")
    else:
        st.sidebar.warning("⚠️ Please select files first.")

# Input section
st.header("💬 Ask a Question from your Documents")
heading = st.text_input("Title / Heading")
addtext = st.text_area("Enter your question")

# Output box
response_placeholder = st.empty()  # for streaming response if needed

if st.button("Submit"):
    if heading.strip() and addtext.strip():
        payload = {
            "prompt_id": "1",
            "heading": heading,
            "addtext": addtext
        }
        with st.spinner("🧠 Thinking..."):
            res = requests.post(f"{BACKEND_URL}/ask/", json=payload)

        if res.status_code == 200:
            result = res.json()["response"]
            with response_placeholder.container():
                st.subheader("📘 Answer:")
                st.markdown(f"""
                <div style="background-color:#f4f4f4;padding:15px;border-radius:10px;border:1px solid #ddd">
                    {result}
                </div>
                """, unsafe_allow_html=True)
        else:
            st.error(f"❌ Failed to get answer: {res.text}")
    else:
        st.warning("⚠️ Please enter both heading and question.")
