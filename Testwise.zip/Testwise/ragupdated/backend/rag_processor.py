import os
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.memory import ConversationBufferMemory
from langchain.llms import Ollama

persist_directory = "chroma_store"
embeddings = OllamaEmbeddings(model="nomic-embed-text")
memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
vectorstore = None

def process_documents(files):
    global vectorstore
    documents = []
    for file in files:
        ext = os.path.splitext(file.filename)[1].lower()
        path = f"temp_{file.filename}"
        with open(path, "wb") as f:
            f.write(file.file.read())

        if ext == ".pdf":
            loader = PyPDFLoader(path)
        elif ext == ".txt":
            loader = TextLoader(path)
        elif ext == ".docx":
            loader = Docx2txtLoader(path)
        else:
            continue

        documents.extend(loader.load())
        os.remove(path)

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    docs = text_splitter.split_documents(documents)

    vectorstore = Chroma.from_documents(
        docs, embeddings, persist_directory=persist_directory
    )
    vectorstore.persist()

    return {"message": "Documents processed successfully."}

def get_qa_chain():
    global vectorstore
    if not vectorstore:
        vectorstore = Chroma(persist_directory=persist_directory, embedding_function=embeddings)
    retriever = vectorstore.as_retriever()
    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=Ollama(model="llama3"),
        retriever=retriever,
        memory=memory
    )
    return qa_chain

def save_history(question, answer):
    with open("chat_history.txt", "a") as f:
        f.write(f"Q: {question}\nA: {answer}\n\n")
