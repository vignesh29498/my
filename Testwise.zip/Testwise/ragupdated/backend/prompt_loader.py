import json

def load_prompt(prompt_id: str):
    with open("backend/prompt.json") as f:
        prompts = json.load(f)
    return prompts.get(prompt_id, "")
