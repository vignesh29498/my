from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from backend.rag_processor import process_documents, get_qa_chain, memory, save_history

app = FastAPI()

origins = ["*"]
app.add_middleware(
    CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

class QuestionRequest(BaseModel):
    question: str

@app.post("/upload/")
async def upload_files(files: List[UploadFile] = File(...)):
    return process_documents(files)

@app.post("/ask/")
async def ask_question(data: QuestionRequest):
    qa = get_qa_chain()
    answer = qa.run(data.question)
    save_history(data.question, answer)
    return {"answer": answer}

@app.get("/download/")
async def download_chat():
    with open("chat_history.txt", "r") as f:
        return {"history": f.read()}
