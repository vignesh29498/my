from pydantic import BaseModel

class AskRequest(BaseModel):
    prompt_id: str
    heading: str
    addtext: str
