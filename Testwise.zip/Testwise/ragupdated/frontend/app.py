import streamlit as st
import requests
import base64

st.set_page_config(page_title="🧠 Agent AI 🧠", layout="centered")

backend_url = "http://127.0.0.1:8000"

# Session State Initialization
if "screen" not in st.session_state:
    st.session_state.screen = 1
if "history" not in st.session_state:
    st.session_state.history = []
if "last_output" not in st.session_state:
    st.session_state.last_output = ""
if "default_prompt" not in st.session_state:
    st.session_state.default_prompt = "Please summarize the uploaded documents."
if "chat_input" not in st.session_state:
    st.session_state.chat_input = ""

# CSS Styling
st.markdown("""
    <style>
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    .stButton>button {
        border-radius: 0.5rem;
        padding: 0.6rem 1.2rem;
    }
    .thinking {
        font-size: 16px;
        color: gray;
        font-style: italic;
        animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
        0% { opacity: 0.3; }
        50% { opacity: 1; }
        100% { opacity: 0.3; }
    }
    .chat-bubble {
        background-color: #f0f2f6;
        border-radius: 12px;
        padding: 10px 14px;
        margin: 6px 0;
    }
    .assistant {
        background-color: #e0f7fa;
    }
    .user {
        background-color: #e8f5e9;
    }
    .download-container {
        display: flex;
        justify-content: flex-end;
    }
    </style>
""", unsafe_allow_html=True)

# Back Button
if st.session_state.screen > 1:
    if st.button("⬅️ Back"):
        st.session_state.screen -= 1

# Screen 1: Upload
st.set_page_config(page_title="🧠 Agent AI 🧠", layout="centered")
if st.session_state.screen == 1:
    st.title("🧠 RAG App with Memory + ChromaDB")
    st.subheader("📂 Upload your documents")
    st.caption("Upload PDF, DOCX, or TXT files")
    uploaded_files = st.file_uploader("Drag and drop files here", type=["pdf", "txt", "docx"], accept_multiple_files=True)
    if st.button("📄 Process Documents"):
        if uploaded_files:
            files = [("files", (file.name, file.read())) for file in uploaded_files]
            res = requests.post(f"{backend_url}/upload/", files=files)
            if res.status_code == 200:
                st.success("✅ Files processed successfully!")
                with st.spinner("🧠 Lets wait buddy i am thinking..."):
                    res = requests.post(f"{backend_url}/ask/", json={"question": st.session_state.default_prompt})
                    if res.status_code == 200:
                        output = res.json()["answer"]
                        st.session_state.last_output = output
                        st.session_state.history.append(("You", st.session_state.default_prompt))
                        st.session_state.history.append(("Assistant", output))
                        st.session_state.screen = 3
                    else:
                        st.error("❌ Failed to get response from backend.")
            else:
                st.error("❌ Upload failed.")
        else:
            st.warning("⚠️ Please upload at least one document.")

# Screen 3: Chat Interface
st.set_page_config(page_title="🧠 Agent AI 🧠", layout="centered")
if st.session_state.screen == 3:
    st.subheader("💬 Chatbot Interface")

    for speaker, message in st.session_state.history:
        speaker_class = "assistant" if speaker == "Assistant" else "user"
        st.markdown(f'<div class="chat-bubble {speaker_class}"><strong>{speaker}:</strong> {message}</div>', unsafe_allow_html=True)

    with st.form(key="chat_form", clear_on_submit=True):
        chat_query = st.text_input("Your message:", key="chat_input")
        submit_chat = st.form_submit_button("📩 Send")

    if submit_chat:
        query = chat_query.strip()
        if query:
            with st.spinner("🧠 Thinking..."):
                res = requests.post(f"{backend_url}/ask/", json={"question": query})
                if res.status_code == 200:
                    output = res.json()["answer"]
                    st.session_state.last_output = output
                    st.session_state.history.append(("You", query))
                    st.session_state.history.append(("Assistant", output))
                    st.rerun()
                else:
                    st.error("❌ Failed to get response from backend.")

    if st.button("📜 Show Full Result"):
        st.session_state.screen = 4

# Screen 4: Full Chat History + Download
st.set_page_config(page_title="🧠 Agent AI 🧠", layout="centered")
if st.session_state.screen == 4:
    st.subheader("🧠 Full Chat History")
    for speaker, text in st.session_state.history:
        st.markdown(f"**{speaker}**: {text}")

    with st.container():
        st.markdown('<div class="download-container">', unsafe_allow_html=True)
        if st.button("⬇️ Download Full Chat History"):
            res = requests.get(f"{backend_url}/download/")
            if res.status_code == 200:
                chat_history = res.json()["history"]
                b64 = base64.b64encode(chat_history.encode()).decode()
                href = f'<a href="data:file/txt;base64,{b64}" download="chat_history.txt">📥 Click here to download your chat history</a>'
                st.markdown(href, unsafe_allow_html=True)
            else:
                st.error("Failed to download chat history.")
        st.markdown('</div>', unsafe_allow_html=True)
